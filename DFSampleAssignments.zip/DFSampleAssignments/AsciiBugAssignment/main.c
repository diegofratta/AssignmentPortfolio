#include "ll.h"
#include "graphics.h"
#include "security.h"
#include <stdlib.h>
#include <stdio.h>

//Main method that encrypts buzz, then decrypts to draw it
int main(){
    printf("\n");
    encrypt();
    draw_buzzEncrypted();
     
    return 0;
}