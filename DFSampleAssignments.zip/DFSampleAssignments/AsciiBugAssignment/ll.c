#include "ll.h"
#include <stdlib.h>
#include <stdio.h>

// creates and initializes a pointer to a linked list
linkedList* createLinkedList(){
  linkedList* lList = (linkedList*) malloc(sizeof(linkedList));
  lList->head = NULL;
  lList->size = 0;
}

// if key is in list return a ptr to node.  Otherwise return NULL
ll_node* find(int key, linkedList* lList) {
  ll_node* this_node = (ll_node*) lList->head;
  
  while(1){ 
     if (this_node->key == key) return this_node;
     this_node = (ll_node*) this_node->next;
  }
  return NULL;  // not found
}


/*
* if key is in list find and modify or if key is not in list allocate and insert a new ll_node into list. 
* Return  ptr to that node. Return NULL if allocation fails
*/
ll_node* insert(int key, int data, linkedList* lList) {
    ll_node* this_node;
    
    if (this_node = find(key, lList)){ //key is in list
        this_node->data = data;
        return this_node;
    }
    // key is not in list
    this_node = (ll_node *) malloc(sizeof(ll_node)); 
    if (!this_node) {
      free(this_node);
      return NULL;
    }

    this_node->data = data;
    this_node->key = key;
    this_node->next = lList->head;
    lList->size++;
    
    return this_node;
}

// delete node with given key.  Return 0 if key is in list and return -1 if not
int delete (int key, linkedList* lList) {
   ll_node* this_node = lList->head;
   ll_node* tmp;
   if (!this_node) return -1;
  
    //if the head is what we are looking for
   if (this_node->key == key) {
       this_node = this_node->next; 
       free(this_node);
       lList->size--;
       return 0;
   }
   
   //otherwise, search for the element
   while (this_node->next){
        if (this_node->next->key == key){
             tmp = this_node->next;
             this_node->next = this_node->next->next; // removing this causes heap-use-after-free on address, common mistake as well
             free(tmp);
            return 0;
        }
    this_node = this_node->next;
  }
  return -1;
}

