These are Diego Fratta's sample assignments for my application to the 
ECE lecturer position at Georgia Tech. You will see 4 folders in this ZIP.

The first folder is AsciiBugAssignment. As of this application I am working
with Dr. Linda Wills to improve aspects of ECE2035 to keep the class updated
and have students be more prepared for the final project in the course. This
is an assignment currently in development to be deployed in Spring 23 and 
student understanding will be surveyed. The assignment involves taking
a buggy sample code on a smaller but similar scale to what students may
see in the final project to help prepare them for debugging on their on
so less time can be spent on debugging and more time can be spent on developing
features required for the baseline and extra credit sections of the project.

The second folder is ECE3710 Worksheets. In the folder there are some worksheets 
that I gave out in my sections of ECE3710 in Fall 22 and Spring 23. 

The third folder is GTQuest. A final project Landon Ballard and I developed for
ECE2035 in Fall 21. The project is to develope an RPG akin to the original 
Legend of Zelda on an Mbed microcontroller. You will see a PDF of the project
and the provided source files we distributed to students.

The fourth folder is mberdle. Another final project Landon and I developed for 
ECE2035 in Spring 22. The project is to develop Wordle on an Mbed microcontroller. 
You will see a PDF of the project and the provided source files we distributed to 
students. While GTQuest was heavily based on a previous project, mberdle was created
with less starter code.