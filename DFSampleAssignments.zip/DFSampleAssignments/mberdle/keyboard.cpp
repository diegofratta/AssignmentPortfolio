#include "keyboard.h"
#include "dictionary.h"
#include <string>




int compareChar(void* input1, void* input2){
    if(*(char*)input1 == *(char*)input2){
        return 1;
    }
    else{
        return 0;
    }
}


void init_keyboard()
{

}


void moveleft()
{

}


void moveright()
{
    
}


void select_letter()
{   

}


void remove_letter()
{   

}

void check_word()
{
       
}
